from fastapi import FastAPI
from pydantic import BaseModel
from dotenv import load_dotenv

from agents.planner import create_plan
from agents.executor import execute_plan
from agents.verifier import verify_result

load_dotenv()

app = FastAPI()


class AskRequest(BaseModel):
    problem: str


@app.post("/ask")
def ask(req: AskRequest):

    plan = create_plan(req.problem)

    execution_result = execute_plan(plan)

    final_result = verify_result(
        req.problem,
        execution_result
    )

    return {
        "plan": plan,
        "execution_result": execution_result,
        "analysis": final_result
    }
