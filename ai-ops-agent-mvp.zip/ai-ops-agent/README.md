# AI Ops Agent MVP

## 安装

```bash
pip install -r requirements.txt
```

## 配置

复制 .env.example 为 .env 并填写 API Key。

## 启动

```bash
uvicorn app:app --reload
```

## 调用

```bash
curl -X POST http://127.0.0.1:8000/ask \
-H "Content-Type: application/json" \
-d '{
  "problem":"服务器 CPU 很高"
}'
```
