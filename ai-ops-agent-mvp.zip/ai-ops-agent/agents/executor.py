import json
from tools.shell_tool import run_shell


def execute_plan(plan_text: str):

    try:
        commands = json.loads(plan_text)
    except:
        return {
            "success": False,
            "error": "LLM 返回 JSON 解析失败"
        }

    results = []

    for cmd in commands:

        result = run_shell(cmd)

        results.append({
            "command": cmd,
            "result": result
        })

    return {
        "success": True,
        "results": results
    }
