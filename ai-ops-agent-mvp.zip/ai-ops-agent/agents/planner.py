from openai import OpenAI
import os

client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY"),
    base_url=os.getenv("OPENAI_BASE_URL")
)

MODEL = os.getenv("MODEL_NAME")


def create_plan(user_problem: str):

    prompt = f"""
你是 Linux 运维专家。

用户问题：
{user_problem}

请生成排查步骤。

要求：
1. 每一步只返回一个 linux 命令
2. 返回 JSON 数组
3. 不要解释

示例：
[
  "top -bn1 | head",
  "df -h",
  "docker ps"
]
"""

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ],
        temperature=0
    )

    return response.choices[0].message.content
