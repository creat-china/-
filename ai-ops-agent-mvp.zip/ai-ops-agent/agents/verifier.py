from openai import OpenAI
import os

client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY"),
    base_url=os.getenv("OPENAI_BASE_URL")
)

MODEL = os.getenv("MODEL_NAME")


def verify_result(problem: str, execution_result):

    prompt = f"""
你是高级 SRE。

用户问题：
{problem}

执行结果：
{execution_result}

请分析：
1. 问题原因
2. 是否已解决
3. 后续建议

输出简洁一点。
"""

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ],
        temperature=0.2
    )

    return response.choices[0].message.content
